﻿namespace SignalRProject
{
    public class ConnectedUsers
    {
        public static List<string> myConnectedUsers=new List<string>();
    }
}
